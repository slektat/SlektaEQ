
package com.tibor.honorsoundbooster

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var audioManager: AudioManager? = null
    private val AUDIO_SESSION = 0

    // 10 savos standard frekik - te kerted a 20-30Hz-t
    private val freqs = listOf("20Hz","31Hz","62Hz","125Hz","250Hz","500Hz","1kHz","4kHz","8kHz","16kHz")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        checkPermissions()
        initEffects()
        setupUI()
    }

    private fun checkPermissions(){
        val perms = mutableListOf<String>()
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) perms.add(Manifest.permission.RECORD_AUDIO)
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        if(perms.isNotEmpty()) ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1001)
    }

    private fun initEffects(){
        try{
            equalizer = Equalizer(0, AUDIO_SESSION).apply{ enabled=true }
            bassBoost = BassBoost(0, AUDIO_SESSION).apply{ enabled=true }
            virtualizer = Virtualizer(0, AUDIO_SESSION).apply{ enabled=true }
            loudness = LoudnessEnhancer(AUDIO_SESSION).apply{ enabled=true }

            val tv = findViewById<TextView>(R.id.tvDeviceInfo)
            val bands = equalizer?.numberOfBands ?: 0
            val bt = audioManager?.isBluetoothA2dpOn
            val range = equalizer?.bandLevelRange?.let{ "${it[0]/100.0} dB - ${it[1]/100.0} dB" } ?: "n/a"
            tv.text = "Session: GLOBAL(0) | BT A2DP: $bt\nHW EQ savok: $bands | Tartomany: $range\nMod: 10 band szoftveres interpolacio + Sub Bass 20Hz"
        }catch(e:Exception){
            Toast.makeText(this, "Audio hiba: ${e.message}. Kapcsold ki a Histen-t!", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupUI(){
        val sbBooster = findViewById<SeekBar>(R.id.sbBooster)
        val tvVol = findViewById<TextView>(R.id.tvVolume)
        val sbSub = findViewById<SeekBar>(R.id.sbSub)
        val tvSub = findViewById<TextView>(R.id.tvSub)
        val sbBass = findViewById<SeekBar>(R.id.sbBass)
        val tvBass = findViewById<TextView>(R.id.tvBass)
        val sbVirt = findViewById<SeekBar>(R.id.sbVirt)
        val tvVirt = findViewById<TextView>(R.id.tvVirt)
        val swSpatial = findViewById<SwitchMaterial>(R.id.swSpatial)

        sbBooster.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?, p:Int, u:Boolean){
                val gain = p*35 // 0-3500 mB ~ +17dB
                loudness?.setTargetGain(gain)
                tvVol.text = "$p% (+${gain/100.0} dB)"
                audioManager?.let{
                    it.setStreamVolume(AudioManager.STREAM_MUSIC, it.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
                }
            }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })

        // SUB BASS 20-30Hz - kulon logika
        sbSub.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?, p:Int, u:Boolean){
                tvSub.text = "Sub: ${p/10}% | 20-30Hz boost"
                // BassBoost 0-1000, de 20Hz-hez extra trukk: BassBoost + EQ legmelyebb sav
                bassBoost?.setStrength( if(p<500) (p*1.5).toInt().coerceAtMost(1000).toShort() else 1000.toShort() )
                // a legmelyebb EQ savot is toli
                try{
                    equalizer?.let{ eq ->
                        if(eq.numberOfBands>0){
                            val idx = 0
                            val min = eq.bandLevelRange[0]
                            val max = eq.bandLevelRange[1]
                            // p 0-1000 -> min-max
                            val level = min + ((max-min)*p/1000.0).toInt()
                            eq.setBandLevel(idx.toShort(), level.toShort())
                        }
                    }
                }catch(_:Exception){}
                // Ha nagyon fel van tolva, Loudness-t is emeli picit
                if(p>700){
                    loudness?.setTargetGain((loudness?.targetGain ?: 0) + 200)
                }
            }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })

        // 10 savos EQ - interpolacio
        val eq = equalizer
        val seekBars = listOf(
            findViewById<SeekBar>(R.id.sbEq0),
            findViewById<SeekBar>(R.id.sbEq1),
            findViewById<SeekBar>(R.id.sbEq2),
            findViewById<SeekBar>(R.id.sbEq3),
            findViewById<SeekBar>(R.id.sbEq4),
            findViewById<SeekBar>(R.id.sbEq5),
            findViewById<SeekBar>(R.id.sbEq6),
            findViewById<SeekBar>(R.id.sbEq7),
            findViewById<SeekBar>(R.id.sbEq8),
            findViewById<SeekBar>(R.id.sbEq9)
        )

        if(eq!=null){
            val min = eq.bandLevelRange[0]
            val max = eq.bandLevelRange[1]
            seekBars.forEachIndexed{ i, sb ->
                // map 10 UI sav -> HW sav (ha csak 5 van, akkor interpolalunk)
                val hwBand = (i * eq.numberOfBands / 10f).toInt().coerceIn(0, eq.numberOfBands-1)
                sb.max = max-min
                sb.progress = (0-min) // flat
                sb.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                    override fun onProgressChanged(s:SeekBar?, p:Int, fromUser:Boolean){
                        try{
                            eq.setBandLevel(hwBand.toShort(), (p+min).toShort())
                            // ha 20Hz sav (i=0) akkor BassBoost-ot is toli vele
                            if(i==0 && p> (max-min)*0.7){
                                bassBoost?.setStrength(800.toShort())
                            }
                        }catch(_:Exception){}
                    }
                    override fun onStartTrackingTouch(s:SeekBar?){}
                    override fun onStopTrackingTouch(s:SeekBar?){}
                })
            }
        }

        sbBass.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?, p:Int, u:Boolean){ bassBoost?.setStrength(p.toShort()); tvBass.text="Bass Boost: ${p/10}%" }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })
        sbVirt.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?, p:Int, u:Boolean){
                try{ virtualizer?.setStrength(p.toShort()); tvVirt.text="3D Virtualizer: ${p/10}%" }catch(_:Exception){ tvVirt.text="3D nem tamogatott BT-n" }
            }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){
            val sp = audioManager?.spatializer
            swSpatial.isChecked = sp?.isEnabled==true
            swSpatial.isEnabled = sp?.isAvailable==true
            swSpatial.setOnCheckedChangeListener{ _, c -> if(sp?.isAvailable==true) sp.isEnabled=c }
        }else swSpatial.isEnabled=false

        // PRESETEK
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnFlat).setOnClickListener{ applyPreset("flat", seekBars) }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBass).setOnClickListener{ applyPreset("bass", seekBars) }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnDeep).setOnClickListener{ applyPreset("deep", seekBars); sbSub.progress=900; sbBass.progress=900 }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnReset).setOnClickListener{
            sbBooster.progress=0; sbSub.progress=0; sbBass.progress=0; sbVirt.progress=0
            applyPreset("flat", seekBars)
            swSpatial.isChecked=false
        }
    }

    private fun applyPreset(name:String, bars:List<SeekBar>){
        val eq = equalizer ?: return
        val min = eq.bandLevelRange[0]
        val max = eq.bandLevelRange[1]
        val range = max-min
        val flat = 0-min

        val presets = mapOf(
            "flat" to List(10){ flat },
            "bass" to listOf(range, range*0.8, range*0.6, range*0.3, flat, flat, flat, flat, flat, flat).map{ (it+min).toInt() },
            "deep" to listOf(range, range, range*0.9, range*0.7, range*0.4, flat, (flat-200).coerceAtLeast(0), (flat-300).coerceAtLeast(0), flat, flat).map{ (it+min).toInt().coerceIn(0, range) }
        )

        val values = presets[name] ?: return
        bars.forEachIndexed{ i, sb ->
            sb.progress = values[i].coerceIn(0, range)
            val hwBand = (i * eq.numberOfBands / 10f).toInt().coerceIn(0, eq.numberOfBands-1)
            eq.setBandLevel(hwBand.toShort(), (values[i]+min).toShort())
        }
        Toast.makeText(this, "Preset: $name", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy(){
        super.onDestroy()
        equalizer?.release(); bassBoost?.release(); virtualizer?.release(); loudness?.release()
    }
}
