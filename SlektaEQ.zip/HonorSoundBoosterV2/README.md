# SLEKTA EQ - Honor Magic 7 Lite Booster

## Mi ez?
- 10 sávos EQ 20Hz-16kHz
- SUB BASS 20-30Hz extra mély
- Hangerő booster gyári fölé Bluetooth-on
- OLED fekete jégkék #00D4FF dizájn
- Márkanév: SLEKTA EQ

## Méret magyarázat
A forrás zip kicsi (pár 10-100KB), mert csak kódot tartalmaz.
A lefordított APK 8-15 MB lesz.

GitHub Actions lefordítja neked APK-vá.

## Build
GitHub Actions > Run workflow > letöltöd az APK-t
