
# Honor Booster V3 - Ice Blue - APK letöltés PC nélkül

A jégkék (#00D4FF) OLED verzió már be van állítva.

## Hogyan kapod meg az APK-t telefonról, PC nélkül?

1. Menj github.com-ra telefonon, csinálj egy új repo-t (pl. honor-booster)
2. Töltsd fel a zip tartalmát (Upload files)
3. Menj a Actions fülre -> Build Honor Booster APK -> Run workflow
4. 2-3 perc múlva megjelenik az artifact: Honor-Booster-V3-IceBlue-APK
5. Töltsd le telefonra, telepítsd

Ennyi, nem kell PC!

## Alternatíva: AIDE app telefonon
- Telepítsd az AIDE - IDE for Android Java C++ appot Play-ből
- Open project -> válaszd a mappát -> Run -> Build APK

A jégkék téma már a kódban van: Theme.HonorBooster.Black #00D4FF
