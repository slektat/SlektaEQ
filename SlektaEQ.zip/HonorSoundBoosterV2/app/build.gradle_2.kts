
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tibor.honorsoundbooster"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tibor.honorsoundbooster"
        minSdk = 28
        targetSdk = 35
        versionCode = 2
        versionName = "3.0-SlektaEQ-IceBlue"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
